---
title: nextSibling
---

```php
nextSibling ( ) : object
```

Returns the next sibling of the current node or null if the current node has no next sibling.