---
title: decode (protected)
---

```php
decode ()
```

Decodes HTML entities in the DOM recursively.